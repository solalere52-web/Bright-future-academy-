-- Run this in the Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  registration_number text not null unique,
  first_name text not null,
  last_name text not null,
  date_of_birth date not null,
  gender text not null,
  email text not null,
  phone text not null,
  address text not null,
  class_name text not null check (class_name in ('Nursery 1','Nursery 2','Primary 1','Primary 2','Primary 3','Primary 4','Primary 5','JSS 1','JSS 2','JSS 3','SS 1','SS 2','SS 3')),
  academic_session text not null default '2026/2027',
  previous_school text not null default '',
  guardian_name text not null,
  guardian_phone text not null,
  fee_amount integer not null check (fee_amount >= 0),
  status text not null default 'pending' check (status in ('pending','under_review','accepted','rejected')),
  payment_status text not null default 'unpaid' check (payment_status in ('unpaid','paid','waived','refunded')),
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null references public.registrations(id) on delete cascade,
  reference text not null unique,
  amount_kobo integer not null check (amount_kobo > 0),
  status text not null default 'pending' check (status in ('pending','paid','failed','refunded')),
  provider_transaction_id text,
  paid_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.student_documents (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null references public.registrations(id) on delete cascade,
  document_type text not null,
  storage_path text not null unique,
  uploaded_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

alter table public.admin_users enable row level security;
alter table public.registrations enable row level security;
alter table public.payments enable row level security;
alter table public.student_documents enable row level security;

-- No public table access is granted. Server-only service role access is used by API routes.
revoke all on public.admin_users from anon, authenticated;
revoke all on public.registrations from anon, authenticated;
revoke all on public.payments from anon, authenticated;
revoke all on public.student_documents from anon, authenticated;

-- Private document bucket. Admin upload/download is performed via server routes.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('student-documents','student-documents',false,5242880,array['application/pdf','image/jpeg','image/png'])
on conflict (id) do update set public=false, file_size_limit=5242880, allowed_mime_types=array['application/pdf','image/jpeg','image/png'];

-- The service role key is only used in server-side route handlers. Never place it in NEXT_PUBLIC variables.
