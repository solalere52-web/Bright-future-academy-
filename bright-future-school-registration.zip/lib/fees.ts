export const CLASS_FEES: Record<string, number> = {
  "Nursery 1": 35000, "Nursery 2": 35000,
  "Primary 1": 45000, "Primary 2": 45000, "Primary 3": 45000,
  "Primary 4": 45000, "Primary 5": 45000,
  "JSS 1": 65000, "JSS 2": 65000, "JSS 3": 65000,
  "SS 1": 85000, "SS 2": 85000, "SS 3": 85000
};
export const formatNaira = (amount: number) =>
  new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 }).format(amount);
