# Bright Future Academy — Online School Registration

A starter project for a Nigerian school's online registration portal.

## Stack
- Next.js App Router + TypeScript
- Supabase Postgres database, Supabase Auth, and private Supabase Storage
- Paystack checkout initialized and verified on the server

## Important
This is a **starter codebase**, not a deployed/live school website. It requires Supabase and Paystack accounts, environment variables, setup, testing, and deployment. Do not use real student data until you have reviewed the security configuration and applicable privacy obligations.

## Setup

1. Install Node.js 20+.
2. Create a Supabase project at https://database.new.
3. In Supabase SQL Editor, run `supabase/schema.sql`.
4. In Supabase Storage, the SQL creates a private `student-documents` bucket. Check that it exists.
5. Create an administrator account in Supabase Authentication > Users (invite/create the account using the dashboard).
6. Copy that user's UUID. In SQL Editor, run:
   ```sql
   insert into public.admin_users (user_id) values ('PASTE-ADMIN-USER-UUID-HERE');
   ```
7. Copy `.env.example` to `.env.local` and fill in the values from Supabase and Paystack. Keep secret keys server-side only.
8. Install dependencies and run:
   ```bash
   npm install
   npm run dev
   ```
9. Open http://localhost:3000.

## Payment setup
- Start with Paystack test keys.
- Configure `PAYSTACK_SECRET_KEY` only as a server environment variable.
- Payment initialization uses the server-side fee table in `lib/fees.ts`; it does not trust an amount sent by the browser.
- The callback endpoint verifies the reference directly with Paystack before marking a registration paid.
- Configure Paystack's webhook URL to `https://YOUR-DOMAIN/api/paystack/webhook` after deployment. The webhook validates `x-paystack-signature`.
- Before live use, test successful, failed, abandoned, duplicate, and delayed payments. Reconcile webhook and callback behavior.

## Security notes
- Student records are not publicly readable. Row Level Security is enabled.
- The admin route checks Supabase Auth plus membership in `admin_users`.
- Document uploads use a private bucket, size/type limits, and a server route that checks the logged-in admin. Students should upload documents through a separately designed authenticated applicant flow before production.
- Supabase service role and Paystack secret keys must never be exposed in `NEXT_PUBLIC_*` variables or committed to source control.
- Add rate limiting, bot protection, backups, retention/deletion rules, audit logs, and an appropriate privacy notice before public launch.
