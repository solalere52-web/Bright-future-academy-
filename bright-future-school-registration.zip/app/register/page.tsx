"use client";
import { useState } from "react";
import Link from "next/link";
import { CLASS_FEES, formatNaira } from "@/lib/fees";

export default function RegisterPage() {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [done, setDone] = useState<{id:string}|null>(null);
  const [payBusy, setPayBusy] = useState(false);
  const [payError, setPayError] = useState("");
  const [form, setForm] = useState({
    first_name:"", last_name:"", date_of_birth:"", gender:"", email:"",
    phone:"", address:"", class_name:"", academic_session:"2026/2027",
    previous_school:"", guardian_name:"", guardian_phone:""
  });
  function change(e: React.ChangeEvent<HTMLInputElement|HTMLSelectElement|HTMLTextAreaElement>) {
    setForm({...form,[e.target.name]:e.target.value});
  }
  async function submit(e: React.FormEvent) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      const res = await fetch("/api/registrations",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});
      const data = await res.json();
      if(!res.ok) throw new Error(data.error || "Registration could not be saved.");
      setDone({id:data.registration.id});
    } catch(err) { setError(err instanceof Error?err.message:"Something went wrong."); }
    finally { setBusy(false); }
  }
  async function startPayment() {
    if (!done) return;
    setPayBusy(true); setPayError("");
    try {
      const r = await fetch("/api/payments/initialize", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({registration_number: done.id}) });
      const data = await r.json();
      if (!r.ok) throw new Error(data.error || "Payment could not be started.");
      window.location.href = data.authorization_url;
    } catch (e) { setPayError(e instanceof Error ? e.message : "Payment could not be started."); }
    finally { setPayBusy(false); }
  }
  if(done) return <main className="wrap"><section className="panel"><h2>Registration submitted</h2><div className="notice">Your reference is <strong>{done.id}</strong>. Save this reference for follow-up.</div><p className="muted">This confirms that the registration record was saved. It does not mean school admission is approved or that fees have been paid.</p>{payError && <div className="notice error">{payError}</div>}<div className="actions"><button onClick={startPayment} disabled={payBusy}>{payBusy?"Connecting to Paystack…":"Pay registration fee (if enabled)"}</button><Link className="button outline" href="/">Back home</Link><Link className="button outline" href="/register">Register another student</Link></div><p className="muted">Online payment requires valid Paystack server credentials and must be tested before public launch.</p></section></main>;
  return <><header className="top"><div className="wrap"><div className="brand"><div className="mark">B</div><div><h1>Bright Future Academy</h1><p>STUDENT REGISTRATION</p></div></div><nav className="nav"><Link href="/">Home</Link><Link href="/admin/login">Administrator login</Link></nav></div></header>
  <main className="wrap"><section className="panel"><h2>Student registration form</h2><p className="muted">Fields marked * are required. Please use accurate information.</p>
    {error && <div className="notice error">{error}</div>}
    <form onSubmit={submit}><div className="formgrid">
      <div className="field"><label>First name *</label><input name="first_name" required maxLength={80} value={form.first_name} onChange={change}/></div>
      <div className="field"><label>Last name *</label><input name="last_name" required maxLength={80} value={form.last_name} onChange={change}/></div>
      <div className="field"><label>Date of birth *</label><input type="date" name="date_of_birth" required value={form.date_of_birth} onChange={change}/></div>
      <div className="field"><label>Gender *</label><select name="gender" required value={form.gender} onChange={change}><option value="">Select</option><option>Female</option><option>Male</option><option>Prefer not to say</option></select></div>
      <div className="field"><label>Student/parent email *</label><input type="email" name="email" required maxLength={254} value={form.email} onChange={change}/></div>
      <div className="field"><label>Student/parent phone *</label><input name="phone" required maxLength={30} value={form.phone} onChange={change}/></div>
      <div className="field full"><label>Home address *</label><textarea name="address" required maxLength={500} value={form.address} onChange={change}/></div>
      <div className="field"><label>Class applying for *</label><select name="class_name" required value={form.class_name} onChange={change}><option value="">Select class</option>{Object.entries(CLASS_FEES).map(([name,fee])=><option value={name} key={name}>{name} — {formatNaira(fee)}</option>)}</select></div>
      <div className="field"><label>Academic session</label><select name="academic_session" value={form.academic_session} onChange={change}><option>2026/2027</option><option>2027/2028</option></select></div>
      <div className="field"><label>Previous school</label><input name="previous_school" maxLength={200} value={form.previous_school} onChange={change}/></div>
      <div className="field"><label>Parent/guardian full name *</label><input name="guardian_name" required maxLength={160} value={form.guardian_name} onChange={change}/></div>
      <div className="field"><label>Parent/guardian phone *</label><input name="guardian_phone" required maxLength={30} value={form.guardian_phone} onChange={change}/></div>
    </div>
    {form.class_name && <div className="notice">Illustrative class fee: <strong>{formatNaira(CLASS_FEES[form.class_name])}</strong>. Payment is a separate step after registration.</div>}
    <p className="muted">By submitting, you confirm that you are permitted to provide these details for the student. Avoid submitting sensitive real student data to a demo deployment.</p>
    <div className="actions"><button disabled={busy}>{busy?"Submitting…":"Submit registration"}</button><Link className="button outline" href="/">Cancel</Link></div></form>
  </section></main></>;
}
