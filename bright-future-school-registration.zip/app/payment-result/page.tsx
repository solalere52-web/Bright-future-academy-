import Link from "next/link";
export default async function PaymentResult({searchParams}:{searchParams:Promise<{status?:string}>}) {
  const {status} = await searchParams;
  const messages:Record<string,{title:string;body:string}> = {
    success:{title:"Payment confirmed",body:"The payment provider confirmed this transaction. Keep your registration reference for your records."},
    unconfirmed:{title:"Payment not yet confirmed",body:"We could not confirm this payment. Do not pay again immediately; check with the school or try again later."},
    invalid:{title:"Missing payment reference",body:"No payment reference was supplied."},
    error:{title:"Verification temporarily unavailable",body:"We could not verify this transaction right now. Please contact the school before trying again."}
  };
  const message=messages[status||""]||messages.unconfirmed;
  return <main className="wrap"><section className="panel" style={{marginTop:30}}><h2>{message.title}</h2><p>{message.body}</p><p className="muted">A browser redirect alone is not proof of payment; the server verifies with Paystack.</p><Link className="button" href="/">Return home</Link></section></main>;
}
