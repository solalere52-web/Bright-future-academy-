"use client";
import { useState } from "react";
export function DocumentUploader({registrationId}:{registrationId:string}){
  const [file,setFile]=useState<File|null>(null);const [kind,setKind]=useState("passport_photo");const [message,setMessage]=useState("");const [busy,setBusy]=useState(false);
  async function upload(){
    if(!file)return;setBusy(true);setMessage("");
    try{const data=new FormData();data.append("file",file);data.append("registration_id",registrationId);data.append("document_type",kind);
      const r=await fetch("/api/admin/documents",{method:"POST",body:data});const j=await r.json();if(!r.ok)throw new Error(j.error||"Upload failed");setMessage("Uploaded securely.");setFile(null);
    }catch(e){setMessage(e instanceof Error?e.message:"Upload failed");}finally{setBusy(false)}
  }
  return <div style={{minWidth:220}}><select value={kind} onChange={e=>setKind(e.target.value)}><option value="passport_photo">Passport photo</option><option value="birth_certificate">Birth certificate</option><option value="previous_results">Previous results</option><option value="other">Other</option></select><input style={{marginTop:8}} type="file" accept=".pdf,.png,.jpg,.jpeg,application/pdf,image/png,image/jpeg" onChange={e=>setFile(e.target.files?.[0]||null)}/><button style={{marginTop:8}} disabled={!file||busy} onClick={upload}>{busy?"Uploading…":"Upload file"}</button>{message&&<p className="muted">{message}</p>}</div>;
}
