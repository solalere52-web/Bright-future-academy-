import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { DocumentUploader } from "./uploader";

export const dynamic = "force-dynamic";
export default async function DocumentsPage(){
  await requireAdmin();
  const db=createAdminClient();
  const {data:registrations}=await db.from("registrations").select("id,registration_number,first_name,last_name").order("created_at",{ascending:false}).limit(200);
  return <><header className="top"><div className="wrap"><div className="brand"><div className="mark">B</div><div><h1>Bright Future Academy</h1><p>PRIVATE DOCUMENT UPLOADS</p></div></div><nav className="nav"><Link href="/admin">Dashboard</Link><Link href="/">Home</Link></nav></div></header><main className="wrap"><section className="panel"><h2>Upload student documents</h2><p className="muted">Admin-only upload tool for associating a document with an existing registration. Accepted formats: PDF, JPG, PNG. Maximum 5 MB each. Files are stored in a private bucket.</p>{!registrations?.length?<p className="muted">Register a student first.</p>:registrations.map(r=><div className="item" key={r.id}><div><strong>{r.first_name} {r.last_name}</strong><p className="muted">{r.registration_number}</p></div><DocumentUploader registrationId={r.id}/></div>)}</section></main></>;
}
