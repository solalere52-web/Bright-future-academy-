import Link from "next/link";
import { requireAdmin } from "@/lib/auth";
import { createAdminClient } from "@/lib/supabase/admin";
import { formatNaira } from "@/lib/fees";
import { signOut } from "./signout";

export const dynamic = "force-dynamic";
export default async function AdminPage(){
  await requireAdmin();
  const admin = createAdminClient();
  const { data: registrations, error } = await admin.from("registrations").select("*").order("created_at",{ascending:false}).limit(500);
  return <><header className="top"><div className="wrap"><div className="brand"><div className="mark">B</div><div><h1>Bright Future Academy</h1><p>ADMIN DASHBOARD</p></div></div><nav className="nav"><Link href="/">Public home</Link><Link href="/admin/documents">Document uploads</Link><form action={signOut}><button className="outline">Sign out</button></form></nav></div></header><main className="wrap"><section className="panel"><h2>Student registrations</h2><p className="muted">Private administrator view. Latest 500 records are shown.</p>{error&&<div className="notice error">Could not load registrations. Check database configuration.</div>}<div className="cards"><div className="stat">Total records<strong>{registrations?.length??0}</strong></div><div className="stat">Pending review<strong>{registrations?.filter(x=>x.status==="pending").length??0}</strong></div><div className="stat">Paid<strong>{registrations?.filter(x=>x.payment_status==="paid").length??0}</strong></div></div>{!registrations?.length?<p className="muted">No registrations have been submitted yet.</p>:registrations.map(r=><article className="item" key={r.id}><div><strong>{r.first_name} {r.last_name}</strong><p className="muted">{r.registration_number} · {r.class_name} · {r.academic_session}</p><p className="muted">{r.email} · {r.phone}</p></div><div><span className="pill">{r.payment_status}</span><p><strong>{formatNaira(r.fee_amount)}</strong></p></div></article>)}</section></main></>;
}
