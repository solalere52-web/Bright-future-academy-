import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Bright Future Academy | Registration",
  description: "Online school registration portal",
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
