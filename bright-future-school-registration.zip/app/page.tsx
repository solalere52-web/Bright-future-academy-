import Link from "next/link";
import { CLASS_FEES, formatNaira } from "@/lib/fees";

export default function Home() {
  return <>
    <header className="top"><div className="wrap">
      <div className="brand"><div className="mark">B</div><div><h1>Bright Future Academy</h1><p>LEARN · GROW · SUCCEED</p></div></div>
      <nav className="nav"><Link href="/">Home</Link><Link href="/register">Student registration</Link><Link href="/admin/login">Administrator login</Link></nav>
    </div></header>
    <main className="wrap">
      <section className="hero"><p className="muted">2026 / 2027 ACADEMIC SESSION</p><h2>Your future starts here.</h2>
        <p>Complete your school registration online. A parent or guardian should provide accurate contact details.</p>
        <div className="actions"><Link className="button" href="/register">Start registration →</Link><Link className="button outline" href="/admin/login">Admin portal</Link></div>
      </section>
      <div className="cards">
        <div className="stat">✍️ <h3>Simple registration</h3><p className="muted">Submit student and guardian information online.</p></div>
        <div className="stat">🔒 <h3>Protected records</h3><p className="muted">Student records are restricted by database access policies.</p></div>
        <div className="stat">💳 <h3>Online payments</h3><p className="muted">Paystack checkout can be enabled after keys are configured.</p></div>
      </div>
      <section className="panel"><h2>Illustrative class fees</h2><p className="muted">These are demo amounts only. Confirm the school's actual fees before launch.</p>
        <div className="grid">{Object.entries(CLASS_FEES).map(([name, fee])=><div key={name} className="item"><span>{name}</span><strong>{formatNaira(fee)}</strong></div>)}</div>
      </section>
    </main><footer className="footer">Bright Future Academy · Demo starter project</footer>
  </>;
}
