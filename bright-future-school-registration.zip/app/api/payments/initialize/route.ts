import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { CLASS_FEES } from "@/lib/fees";

export async function POST(req: Request) {
  try {
    const { registration_number } = await req.json();
    if (typeof registration_number !== "string" || registration_number.length > 80)
      return NextResponse.json({ error: "A valid registration reference is required." }, { status: 400 });
    const db = createAdminClient();
    const { data: reg } = await db.from("registrations").select("id,registration_number,email,class_name,fee_amount,payment_status").eq("registration_number",registration_number).maybeSingle();
    if (!reg) return NextResponse.json({ error: "Registration not found." }, { status: 404 });
    if (reg.payment_status === "paid") return NextResponse.json({ error: "This registration is already paid." }, { status: 409 });
    if (CLASS_FEES[reg.class_name] !== reg.fee_amount) return NextResponse.json({ error: "Fee configuration mismatch. Contact the school." }, { status: 409 });
    const secret = process.env.PAYSTACK_SECRET_KEY;
    if (!secret) return NextResponse.json({ error: "Online payments are not configured yet." }, { status: 503 });
    const reference = `BFA-${crypto.randomUUID().replaceAll("-","")}`;
    const origin = process.env.NEXT_PUBLIC_SITE_URL || new URL(req.url).origin;
    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: { Authorization: `Bearer ${secret}`, "Content-Type": "application/json" },
      body: JSON.stringify({ email: reg.email, amount: String(reg.fee_amount * 100), currency: "NGN", reference, callback_url: `${origin}/api/payments/callback`, metadata: { registration_number: reg.registration_number } }),
      cache: "no-store"
    });
    const result = await response.json();
    if (!response.ok || !result.status || !result.data?.authorization_url) {
      console.error("Paystack initialization failed", result.message);
      return NextResponse.json({ error: "Could not start payment. Please try again." }, { status: 502 });
    }
    const { error } = await db.from("payments").insert({ registration_id: reg.id, reference, amount_kobo: reg.fee_amount * 100, status: "pending" });
    if (error) {
      console.error("Payment record insert failed", error.message);
      return NextResponse.json({ error: "Could not save payment reference." }, { status: 500 });
    }
    return NextResponse.json({ authorization_url: result.data.authorization_url });
  } catch {
    return NextResponse.json({ error: "Unable to initialize payment." }, { status: 500 });
  }
}
