import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";

async function verifyAndRecord(reference: string) {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) throw new Error("Payment provider not configured");
  const response = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
    headers: { Authorization: `Bearer ${secret}` }, cache: "no-store"
  });
  const result = await response.json();
  if (!response.ok || !result.status || result.data?.status !== "success" || result.data?.reference !== reference) return false;
  const db = createAdminClient();
  const { data: payment } = await db.from("payments").select("id,registration_id,amount_kobo,status").eq("reference",reference).maybeSingle();
  if (!payment || payment.amount_kobo !== result.data.amount || result.data.currency !== "NGN") return false;
  const { error: pErr } = await db.from("payments").update({status:"paid",provider_transaction_id:String(result.data.id),paid_at:new Date().toISOString()}).eq("id",payment.id).neq("status","paid");
  if (pErr) throw pErr;
  const { error: rErr } = await db.from("registrations").update({payment_status:"paid"}).eq("id",payment.registration_id);
  if (rErr) throw rErr;
  return true;
}
export async function GET(req: Request) {
  const url = new URL(req.url); const reference = url.searchParams.get("reference");
  if (!reference || reference.length > 120) return NextResponse.redirect(new URL("/payment-result?status=invalid", url.origin));
  try {
    const ok = await verifyAndRecord(reference);
    return NextResponse.redirect(new URL(`/payment-result?status=${ok?"success":"unconfirmed"}`,url.origin));
  } catch { return NextResponse.redirect(new URL("/payment-result?status=error",url.origin)); }
}
