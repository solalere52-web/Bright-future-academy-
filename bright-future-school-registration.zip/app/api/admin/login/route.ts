import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export async function POST(req: Request) {
  try {
    const { email, password } = await req.json();
    if (typeof email !== "string" || typeof password !== "string" || !email || !password)
      return NextResponse.json({ error: "Email and password are required." }, { status: 400 });
    const supabase = await createClient();
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error || !data.user) return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    const admin = createAdminClient();
    const { data: allowed } = await admin.from("admin_users").select("user_id").eq("user_id", data.user.id).maybeSingle();
    if (!allowed) {
      await supabase.auth.signOut();
      return NextResponse.json({ error: "This account is not authorized as a school administrator." }, { status: 403 });
    }
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "Unable to sign in. Check server configuration." }, { status: 500 });
  }
}
