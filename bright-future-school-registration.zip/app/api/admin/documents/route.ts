import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

const MAX_BYTES=5*1024*1024;
const allowed:Record<string,string>={"application/pdf":"pdf","image/jpeg":"jpg","image/png":"png"};
export async function POST(req:Request){
  try{
    const supabase=await createClient();
    const {data:{user}}=await supabase.auth.getUser();
    if(!user)return NextResponse.json({error:"Sign in required."},{status:401});
    const admin=createAdminClient();
    const {data:allowedAdmin}=await admin.from("admin_users").select("user_id").eq("user_id",user.id).maybeSingle();
    if(!allowedAdmin)return NextResponse.json({error:"Administrator access required."},{status:403});
    const form=await req.formData();const file=form.get("file");const registrationId=form.get("registration_id");const type=form.get("document_type");
    if(!(file instanceof File)||typeof registrationId!=="string"||typeof type!=="string")return NextResponse.json({error:"Missing upload details."},{status:400});
    if(file.size<1||file.size>MAX_BYTES)return NextResponse.json({error:"File must be 1 byte to 5 MB."},{status:400});
    const ext=allowed[file.type];if(!ext)return NextResponse.json({error:"Only PDF, JPG, and PNG files are accepted."},{status:400});
    const {data:reg}=await admin.from("registrations").select("id").eq("id",registrationId).maybeSingle();
    if(!reg)return NextResponse.json({error:"Registration not found."},{status:404});
    const safeType=type.replace(/[^a-z0-9_-]/gi,"").slice(0,40);
    const path=`${registrationId}/${crypto.randomUUID()}-${safeType}.${ext}`;
    const {error:uploadError}=await admin.storage.from("student-documents").upload(path,file,{contentType:file.type,upsert:false});
    if(uploadError){console.error("Document upload failed",uploadError.message);return NextResponse.json({error:"Upload failed."},{status:500});}
    const {error:dbError}=await admin.from("student_documents").insert({registration_id:registrationId,document_type:safeType,storage_path:path,uploaded_by:user.id});
    if(dbError){await admin.storage.from("student-documents").remove([path]);return NextResponse.json({error:"Could not record uploaded document."},{status:500});}
    return NextResponse.json({ok:true});
  }catch{return NextResponse.json({error:"Upload could not be completed."},{status:500});}
}
