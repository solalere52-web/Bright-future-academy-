import { NextResponse } from "next/server";
import crypto from "node:crypto";
import { createAdminClient } from "@/lib/supabase/admin";

export async function POST(req: Request) {
  const secret = process.env.PAYSTACK_SECRET_KEY;
  if (!secret) return NextResponse.json({error:"Not configured"},{status:503});
  const raw = await req.text();
  const signature = req.headers.get("x-paystack-signature") || "";
  const digest = crypto.createHmac("sha512",secret).update(raw).digest("hex");
  const a = Buffer.from(signature); const b = Buffer.from(digest);
  if (a.length !== b.length || !crypto.timingSafeEqual(a,b)) return NextResponse.json({error:"Invalid signature"},{status:401});
  try {
    const event = JSON.parse(raw);
    if (event.event !== "charge.success") return NextResponse.json({received:true});
    const tx = event.data;
    if (!tx?.reference || tx.status !== "success" || tx.currency !== "NGN") return NextResponse.json({received:true});
    const db = createAdminClient();
    const { data: payment } = await db.from("payments").select("id,registration_id,amount_kobo,status").eq("reference",tx.reference).maybeSingle();
    if (!payment || payment.amount_kobo !== tx.amount) return NextResponse.json({error:"Payment mismatch"},{status:400});
    if (payment.status !== "paid") {
      const { error } = await db.from("payments").update({status:"paid",provider_transaction_id:String(tx.id),paid_at:new Date().toISOString()}).eq("id",payment.id);
      if (error) throw error;
      const { error: regError } = await db.from("registrations").update({payment_status:"paid"}).eq("id",payment.registration_id);
      if (regError) throw regError;
    }
    return NextResponse.json({received:true});
  } catch { return NextResponse.json({error:"Webhook processing failed"},{status:500}); }
}
