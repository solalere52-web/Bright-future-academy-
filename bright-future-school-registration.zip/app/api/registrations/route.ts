import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { CLASS_FEES } from "@/lib/fees";

const required = ["first_name","last_name","date_of_birth","gender","email","phone","address","class_name","guardian_name","guardian_phone"] as const;
export async function POST(req: Request) {
  try {
    const body = await req.json();
    for (const key of required) {
      if (typeof body[key] !== "string" || !body[key].trim())
        return NextResponse.json({ error: `Please complete ${key.replaceAll("_"," ")}.` }, { status: 400 });
      if (body[key].length > 1000) return NextResponse.json({ error: "One or more fields are too long." }, { status: 400 });
    }
    if (!Object.hasOwn(CLASS_FEES, body.class_name))
      return NextResponse.json({ error: "Please choose a valid class." }, { status: 400 });
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email))
      return NextResponse.json({ error: "Enter a valid email address." }, { status: 400 });
    const dob = new Date(body.date_of_birth);
    if (Number.isNaN(dob.getTime()) || dob > new Date())
      return NextResponse.json({ error: "Enter a valid date of birth." }, { status: 400 });

    const admin = createAdminClient();
    const number = `BFA-${Date.now().toString(36).toUpperCase()}-${crypto.randomUUID().slice(0,6).toUpperCase()}`;
    const { data, error } = await admin.from("registrations").insert({
      registration_number: number,
      first_name: body.first_name.trim(), last_name: body.last_name.trim(),
      date_of_birth: body.date_of_birth, gender: body.gender,
      email: body.email.trim().toLowerCase(), phone: body.phone.trim(),
      address: body.address.trim(), class_name: body.class_name,
      academic_session: body.academic_session === "2027/2028" ? "2027/2028" : "2026/2027",
      previous_school: typeof body.previous_school === "string" ? body.previous_school.trim() : "",
      guardian_name: body.guardian_name.trim(), guardian_phone: body.guardian_phone.trim(),
      fee_amount: CLASS_FEES[body.class_name], status: "pending", payment_status: "unpaid"
    }).select("id,registration_number").single();
    if (error || !data) {
      console.error("Registration insert failed", error?.message);
      return NextResponse.json({ error: "Registration could not be saved. Please try again later." }, { status: 500 });
    }
    return NextResponse.json({ registration: { id: data.registration_number } }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "Invalid request or server configuration error." }, { status: 500 });
  }
}
